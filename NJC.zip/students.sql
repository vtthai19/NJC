-- 1. Setup a local database, create a table, insert some records using any database client. Please use MySQL database if you can. 

--
-- Table structure for table `students`
--
create table students (
  id int unsigned auto_increment not null,
  first_name varchar(32) not null,
  last_name varchar(32) not null,
  enrollment_date varchar(32) not null,
  is_freshman boolean,
  credits int,
  primary key (id)
);

--
-- Insert data for table `students`
--
insert into `students` (`id`, `first_name`, `last_name`, `enrollment_date`, `is_freshman`, `credits`) values
('1000', 'Deepak ', 'Saxana ', 'Spring of 2020 ', 'True ', '12 '),
('1001', 'Anita ', 'George ', 'Spring of 2020 ', 'True ', '9 '),
('1002', 'Joe ', 'James ', 'Fall of 2019 ', 'True ', '12 '),
('1003', 'Jesus ', 'Gonzales ', 'Spring of 2018 ', 'False ', '30 '),
('1004', 'Jackie ', 'SaxJohnsonana ', 'Summer of 2019 ', 'True ', '15 ');