/*
 * Testing REST�API�in JAVA
 * Using Apache Tomcat
 */

package pkgTest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@Path("/test")
public class clsTest {
	@GET
	@Produces(MediaType.TEXT_XML)
	public String doTest_XML()
	{
		//String resource=null;
		String resource="<? xml version='1.0' ?>" +
		"<test> This is a test from XML </test>";
		return resource;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String doTest_JASON()
	{
		String resource=null;
		return resource;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String doTest_HTML()
	{
		String resource="<h1> This is a test from HTML </h1>";
		return resource;
	}
	

}
