/*
3. Write Java code to retrieve the same records
*/


package mySQL_Records;

import java.sql.*;

/*
 * A Java MySQL SELECT statement to retrieve all records from the table 'studentreport'.
 * Demonstrates the use of a SQL SELECT statement against a
 * MySQL database, called from a Java program.
 */
public class JavaMysqlRetrieveRecords
{

  public static void main(String[] args)
  {
	System.out.println("Using Java to retrieve MySQL records");
    try
    {
      // create mysql database connection
      String myDriver = "org.gjt.mm.mysql.Driver";
      String myUrl = "jdbc:mysql://localhost/test";
      Class.forName(myDriver);
      Connection conn = DriverManager.getConnection(myUrl, "root", "p@ssword");
      
      // SQL SELECT query. 
      String query = "SELECT * FROM students";

      // create the java statement
      Statement st = conn.createStatement();
      
      // execute the query, and get a java resultset
      ResultSet rs = st.executeQuery(query);
      
      // iterate through the java resultset
      while (rs.next())
      {
        int id = rs.getInt("id");
        String firstName = rs.getString("first_name");
        String lastName = rs.getString("last_name");
        Date dateEnrollment = rs.getDate("enrollment_date");
        boolean isFreshman = rs.getBoolean("is_freshman");
        int credits = rs.getInt("credits");
        
        // print the results
        System.out.format("%s, %s, %s, %s, %s, %s\n", id, firstName, lastName, dateEnrollment, isFreshman, credits);
      }
      st.close();
    }
    catch (Exception e)
    {
      System.err.println("Got an exception! ");
      System.err.println(e.getMessage());
    }
  }
}